
export const firebaseConfig = {
  // Your web app's Firebase configuration here
  // See https://firebase.google.com/docs/web/setup#add-sdks-initialize
  //apiKey: 'API_KEY',
  //authDomain: 'PROJECT_ID.firebaseapp.com',
  databaseURL: 'https://file-submit-test-default-rtdb.firebaseio.com',
  //projectId: 'PROJECT_ID',
  //storageBucket: 'PROJECT_ID.appspot.com',
  //messagingSenderId: 'SENDER_ID',
  //appId: 'APP_ID',
  measurementId: 'G-MEASUREMENT_ID',
  apiKey: "AIzaSyA54xMhLtR-6rpL0Oit9zdS1onPvFxr5fI",
  authDomain: "file-submit-test.firebaseapp.com",
  projectId: "file-submit-test",
  storageBucket: "file-submit-test.firebasestorage.app",
  messagingSenderId: "933346969216",
  appId: "1:933346969216:web:f849a51b54642046df0865"
};
